import { StyleSheet, Text, View } from "react-native";

export default function ManagerScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>👩‍💼 Manager Dashboard</Text>
      <Text>Order received successfully!</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 15 },
});