import axios from "axios";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Alert, StyleSheet, Text, TouchableOpacity, View } from "react-native";

const SERVER_URL = "http://192.168.10.49:3000"; // same IP

export default function CartScreen() {
  const { item } = useLocalSearchParams();
  const router = useRouter();
  const parsedItem = item ? JSON.parse(item as string) : null;

  const placeOrder = () => {
    axios.post(`${SERVER_URL}/order`, {
      customerName: "Alina",
      items: [parsedItem.name],
      totalAmount: parsedItem.price,
    })
      .then(() => {
        Alert.alert("Order Placed!");
        router.push("/(tabs)/manager");
      })
      .catch(err => console.log(err));
  };

  if (!parsedItem) return null;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🛒 Cart</Text>
      <Text style={styles.item}>{parsedItem.name}</Text>
      <Text style={styles.price}>Rs. {parsedItem.price}</Text>

      <TouchableOpacity style={styles.button} onPress={placeOrder}>
        <Text style={{ color: "#fff" }}>Place Order</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 20 },
  item: { fontSize: 18 },
  price: { fontSize: 16, marginVertical: 10 },
  button: {
    backgroundColor: "#27ae60",
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
  },
});