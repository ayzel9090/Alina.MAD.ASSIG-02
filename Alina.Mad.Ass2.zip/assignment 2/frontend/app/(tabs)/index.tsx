import axios from "axios";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";

const SERVER_URL = "http://192.168.10.49:3000"; // 🔥 replace IP

export default function HomeScreen() {
  const [menu, setMenu] = useState<any[]>([]);
  const router = useRouter();

  useEffect(() => {
    axios.get(`${SERVER_URL}/menu`)
      .then(res => setMenu(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <View style={{ flex: 1 }}>
      <LinearGradient
        colors={["#2c3e50", "#4ca1af"]}
        style={styles.header}
      >
        <Text style={styles.logo}>☕ Alina's Cafe</Text>
        <Text style={styles.subtitle}>Fresh & Delicious</Text>
      </LinearGradient>

      <FlatList
        data={menu}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.price}>Rs. {item.price}</Text>

            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                router.push({
                  pathname: "/(tabs)/cart",
                  params: { item: JSON.stringify(item) },
                })
              }
            >
              <Text style={styles.buttonText}>Add to Cart</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    padding: 25,
    alignItems: "center",
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
  },
  logo: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#fff",
  },
  subtitle: {
    color: "#ecf0f1",
    marginTop: 5,
  },
  card: {
    backgroundColor: "#fff",
    margin: 15,
    borderRadius: 15,
    padding: 15,
    elevation: 5,
  },
  image: {
    width: "100%",
    height: 160,
    borderRadius: 12,
  },
  name: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 10,
  },
  price: {
    color: "#27ae60",
    fontWeight: "bold",
    marginVertical: 8,
  },
  button: {
    backgroundColor: "#e67e22",
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
});