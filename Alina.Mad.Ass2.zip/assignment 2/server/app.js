const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

// ----------------------
// HARDCODED MENU DATA
// ----------------------
const menu = [
  {
    id: 1,
    name: "Margherita Pizza",
    price: 1200,
    category: "Daily Specials",
    image: "https://images.unsplash.com/photo-1601924582975-7e6f4e1f2c9c"
  },
  {
    id: 2,
    name: "Zinger Burger",
    price: 550,
    category: "Fast Food",
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349"
  },
  {
    id: 3,
    name: "Pasta Alfredo",
    price: 900,
    category: "Italian",
    image: "https://images.unsplash.com/photo-1589308078059-be1415eab4c3"
  },
  {
    id: 4,
    name: "Chocolate Shake",
    price: 350,
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699"
  }
];

// ----------------------
// GET ENDPOINT (Catalog)
// ----------------------
app.get('/menu', (req, res) => {
  res.json(menu);
});

// ----------------------
// POST ENDPOINT (Order Logger)
// ----------------------
app.post('/order', (req, res) => {
  const order = req.body;

  console.log("===== NEW ORDER RECEIVED =====");
  console.log("Customer Name:", order.customerName);
  console.log("Items:", order.items);
  console.log("Total:", order.totalAmount);
  console.log("==============================");

  res.json({
    message: "Order received successfully!"
  });
});

// ----------------------
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});